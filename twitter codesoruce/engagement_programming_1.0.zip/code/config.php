<?php
	
// Database values for db_lib.php
$db_user = 'xxxx';
$db_password = 'xxxx';
$db_name = 'engagement';

// Engagement account
$engagement_user_id = xxxx;
$engagement_screen_name = 'xxxx';

// OAuth tokens for oauth_lib.php
$consumer_key = 'xxxx';
$consumer_secret = 'xxxx';
$user_token = 'xxxx';
$user_secret = 'xxxx';
	
// Auto tweet settings
$autotweet_start = 10;
$autotweet_stop = 22;
$default_tag = "#xxxx";
$max_daily_follow_tweets = 5;

// Report settings
$results_per_page = 100;
	
?>